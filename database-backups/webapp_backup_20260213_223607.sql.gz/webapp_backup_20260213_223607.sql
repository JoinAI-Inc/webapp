--
-- PostgreSQL database dump
--

\restrict s8vsj1IAp6Be1PImIHJIo8V3Cf4uXhtqMqxYkrWm1iE4P1KymzUBLQl4nqtp12a

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_social_binds DROP CONSTRAINT IF EXISTS user_social_binds_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_entitlements DROP CONSTRAINT IF EXISTS user_entitlements_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_entitlements DROP CONSTRAINT IF EXISTS user_entitlements_source_order_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_entitlement_apps DROP CONSTRAINT IF EXISTS user_entitlement_apps_entitlement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_entitlement_apps DROP CONSTRAINT IF EXISTS user_entitlement_apps_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pricing_plan_apps DROP CONSTRAINT IF EXISTS pricing_plan_apps_pricing_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pricing_plan_apps DROP CONSTRAINT IF EXISTS pricing_plan_apps_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pricing_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.media_files DROP CONSTRAINT IF EXISTS media_files_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_user_id_fkey;
DROP INDEX IF EXISTS public.verification_tokens_token_key;
DROP INDEX IF EXISTS public.verification_tokens_identifier_token_key;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public.user_social_binds_user_id_idx;
DROP INDEX IF EXISTS public.user_social_binds_provider_provider_sub_key;
DROP INDEX IF EXISTS public.user_entitlements_user_id_status_expire_time_idx;
DROP INDEX IF EXISTS public.user_entitlement_apps_entitlement_id_app_id_key;
DROP INDEX IF EXISTS public.sessions_user_id_idx;
DROP INDEX IF EXISTS public.sessions_session_token_key;
DROP INDEX IF EXISTS public.pricing_plan_apps_pricing_plan_id_app_id_key;
DROP INDEX IF EXISTS public.orders_stripe_subscription_id_idx;
DROP INDEX IF EXISTS public.orders_stripe_session_id_idx;
DROP INDEX IF EXISTS public.orders_order_no_key;
DROP INDEX IF EXISTS public.media_files_user_id_created_at_idx;
DROP INDEX IF EXISTS public.media_files_status_idx;
DROP INDEX IF EXISTS public.media_files_file_type_idx;
DROP INDEX IF EXISTS public.media_files_created_at_idx;
DROP INDEX IF EXISTS public.media_files_app_id_idx;
DROP INDEX IF EXISTS public.apps_app_key_key;
DROP INDEX IF EXISTS public.accounts_user_id_idx;
DROP INDEX IF EXISTS public.accounts_provider_provider_account_id_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_social_binds DROP CONSTRAINT IF EXISTS user_social_binds_pkey;
ALTER TABLE IF EXISTS ONLY public.user_entitlements DROP CONSTRAINT IF EXISTS user_entitlements_pkey;
ALTER TABLE IF EXISTS ONLY public.user_entitlement_apps DROP CONSTRAINT IF EXISTS user_entitlement_apps_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.pricing_plans DROP CONSTRAINT IF EXISTS pricing_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.pricing_plan_apps DROP CONSTRAINT IF EXISTS pricing_plan_apps_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.media_files DROP CONSTRAINT IF EXISTS media_files_pkey;
ALTER TABLE IF EXISTS ONLY public.apps DROP CONSTRAINT IF EXISTS apps_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
ALTER TABLE IF EXISTS public.user_social_binds ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_entitlements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_entitlement_apps ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pricing_plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pricing_plan_apps ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.apps ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.verification_tokens;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_social_binds_id_seq;
DROP TABLE IF EXISTS public.user_social_binds;
DROP SEQUENCE IF EXISTS public.user_entitlements_id_seq;
DROP TABLE IF EXISTS public.user_entitlements;
DROP SEQUENCE IF EXISTS public.user_entitlement_apps_id_seq;
DROP TABLE IF EXISTS public.user_entitlement_apps;
DROP TABLE IF EXISTS public.sessions;
DROP SEQUENCE IF EXISTS public.pricing_plans_id_seq;
DROP TABLE IF EXISTS public.pricing_plans;
DROP SEQUENCE IF EXISTS public.pricing_plan_apps_id_seq;
DROP TABLE IF EXISTS public.pricing_plan_apps;
DROP SEQUENCE IF EXISTS public.orders_id_seq;
DROP TABLE IF EXISTS public.orders;
DROP TABLE IF EXISTS public.media_files;
DROP SEQUENCE IF EXISTS public.apps_id_seq;
DROP TABLE IF EXISTS public.apps;
DROP TABLE IF EXISTS public.accounts;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TYPE IF EXISTS public."UserStatus";
DROP TYPE IF EXISTS public."PlanType";
DROP TYPE IF EXISTS public."PlanStatus";
DROP TYPE IF EXISTS public."OrderStatus";
DROP TYPE IF EXISTS public."EntitlementType";
DROP TYPE IF EXISTS public."EntitlementStatus";
DROP TYPE IF EXISTS public."BillingInterval";
DROP TYPE IF EXISTS public."AppStatus";
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AppStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'UNLISTED',
    'DISABLED',
    'SUNSET',
    'ARCHIVED'
);


ALTER TYPE public."AppStatus" OWNER TO postgres;

--
-- Name: BillingInterval; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BillingInterval" AS ENUM (
    'MONTH',
    'QUARTER',
    'YEAR'
);


ALTER TYPE public."BillingInterval" OWNER TO postgres;

--
-- Name: EntitlementStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EntitlementStatus" AS ENUM (
    'ACTIVE',
    'EXPIRED',
    'REVOKED'
);


ALTER TYPE public."EntitlementStatus" OWNER TO postgres;

--
-- Name: EntitlementType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EntitlementType" AS ENUM (
    'SUBSCRIPTION',
    'PERMANENT'
);


ALTER TYPE public."EntitlementType" OWNER TO postgres;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED',
    'REFUNDED'
);


ALTER TYPE public."OrderStatus" OWNER TO postgres;

--
-- Name: PlanStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PlanStatus" AS ENUM (
    'ACTIVE',
    'RETIRED',
    'ARCHIVED'
);


ALTER TYPE public."PlanStatus" OWNER TO postgres;

--
-- Name: PlanType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PlanType" AS ENUM (
    'SUBSCRIPTION',
    'ONE_TIME'
);


ALTER TYPE public."PlanType" OWNER TO postgres;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'LOCKED'
);


ALTER TYPE public."UserStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    provider_account_id text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: apps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.apps (
    id bigint NOT NULL,
    app_key text NOT NULL,
    name text NOT NULL,
    description text,
    access_url text NOT NULL,
    status public."AppStatus" DEFAULT 'DRAFT'::public."AppStatus" NOT NULL,
    purchasable boolean DEFAULT true NOT NULL,
    allow_in_new_plan boolean DEFAULT true NOT NULL,
    sunset_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    archived_reason text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.apps OWNER TO postgres;

--
-- Name: apps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.apps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.apps_id_seq OWNER TO postgres;

--
-- Name: apps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.apps_id_seq OWNED BY public.apps.id;


--
-- Name: media_files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_files (
    id text NOT NULL,
    app_id text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    mime_type text NOT NULL,
    file_size bigint NOT NULL,
    width integer,
    height integer,
    duration integer,
    storage_key text NOT NULL,
    storage_url text NOT NULL,
    thumbnail_url text,
    tags jsonb,
    metadata jsonb,
    status text DEFAULT 'active'::text NOT NULL,
    deleted_at timestamp(3) without time zone,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    user_id text,
    generation_type text,
    prompt_data jsonb
);


ALTER TABLE public.media_files OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    order_no text NOT NULL,
    user_id text NOT NULL,
    pricing_plan_id bigint NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text NOT NULL,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    stripe_session_id text,
    stripe_payment_intent_id text,
    paid_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    stripe_invoice_id text,
    stripe_metadata jsonb,
    stripe_subscription_id text
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: pricing_plan_apps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pricing_plan_apps (
    id bigint NOT NULL,
    pricing_plan_id bigint NOT NULL,
    app_id bigint NOT NULL
);


ALTER TABLE public.pricing_plan_apps OWNER TO postgres;

--
-- Name: pricing_plan_apps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pricing_plan_apps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pricing_plan_apps_id_seq OWNER TO postgres;

--
-- Name: pricing_plan_apps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pricing_plan_apps_id_seq OWNED BY public.pricing_plan_apps.id;


--
-- Name: pricing_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pricing_plans (
    id bigint NOT NULL,
    name text NOT NULL,
    plan_type public."PlanType" NOT NULL,
    price numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    billing_interval public."BillingInterval",
    stripe_product_id text,
    stripe_price_id text,
    is_active boolean DEFAULT true NOT NULL,
    status public."PlanStatus" DEFAULT 'ACTIVE'::public."PlanStatus" NOT NULL,
    sellable boolean DEFAULT true NOT NULL,
    retired_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    archived_reason text,
    replacement_plan_id bigint,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    stripe_metadata jsonb,
    stripe_price_id_monthly text,
    stripe_price_id_quarterly text,
    stripe_price_id_yearly text
);


ALTER TABLE public.pricing_plans OWNER TO postgres;

--
-- Name: pricing_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pricing_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pricing_plans_id_seq OWNER TO postgres;

--
-- Name: pricing_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pricing_plans_id_seq OWNED BY public.pricing_plans.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    session_token text NOT NULL,
    user_id text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: user_entitlement_apps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_entitlement_apps (
    id bigint NOT NULL,
    entitlement_id bigint NOT NULL,
    app_id bigint NOT NULL
);


ALTER TABLE public.user_entitlement_apps OWNER TO postgres;

--
-- Name: user_entitlement_apps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_entitlement_apps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_entitlement_apps_id_seq OWNER TO postgres;

--
-- Name: user_entitlement_apps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_entitlement_apps_id_seq OWNED BY public.user_entitlement_apps.id;


--
-- Name: user_entitlements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_entitlements (
    id bigint NOT NULL,
    user_id text NOT NULL,
    source_order_id bigint,
    entitlement_type public."EntitlementType" NOT NULL,
    start_time timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expire_time timestamp(3) without time zone,
    status public."EntitlementStatus" DEFAULT 'ACTIVE'::public."EntitlementStatus" NOT NULL,
    stripe_subscription_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_entitlements OWNER TO postgres;

--
-- Name: user_entitlements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_entitlements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_entitlements_id_seq OWNER TO postgres;

--
-- Name: user_entitlements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_entitlements_id_seq OWNED BY public.user_entitlements.id;


--
-- Name: user_social_binds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_social_binds (
    id bigint NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    provider_sub text NOT NULL,
    social_email text,
    social_name text,
    social_avatar text,
    access_token text,
    refresh_token text,
    token_expires_at timestamp(3) without time zone,
    raw_data text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_social_binds OWNER TO postgres;

--
-- Name: user_social_binds_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_social_binds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_social_binds_id_seq OWNER TO postgres;

--
-- Name: user_social_binds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_social_binds_id_seq OWNED BY public.user_social_binds.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text,
    password_hash text,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    stripe_customer_id text,
    total_spend_amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    total_order_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    email_verified timestamp(3) without time zone,
    image text,
    name text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.verification_tokens OWNER TO postgres;

--
-- Name: apps id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apps ALTER COLUMN id SET DEFAULT nextval('public.apps_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: pricing_plan_apps id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricing_plan_apps ALTER COLUMN id SET DEFAULT nextval('public.pricing_plan_apps_id_seq'::regclass);


--
-- Name: pricing_plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricing_plans ALTER COLUMN id SET DEFAULT nextval('public.pricing_plans_id_seq'::regclass);


--
-- Name: user_entitlement_apps id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entitlement_apps ALTER COLUMN id SET DEFAULT nextval('public.user_entitlement_apps_id_seq'::regclass);


--
-- Name: user_entitlements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entitlements ALTER COLUMN id SET DEFAULT nextval('public.user_entitlements_id_seq'::regclass);


--
-- Name: user_social_binds id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_social_binds ALTER COLUMN id SET DEFAULT nextval('public.user_social_binds_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b633d622-a08a-43f8-9a25-c8e7ac25df28	53b77cd41f0b054fc9415e6c77dd32b626a0574bc5fe7bb9d488512c4d1716e0	2026-02-11 03:33:52.673169+00	20260109064411_add_lifecycle_fields	\N	\N	2026-02-11 03:33:52.524401+00	1
215835b5-0d09-4f01-9bf4-d0d87e015db8	d32c78675f1c71e4f4012ea7aa84dc72a7fd311d57fda564e25212d791da8455	2026-02-11 03:33:52.685988+00	20260109084001_add_stripe_fields	\N	\N	2026-02-11 03:33:52.674765+00	1
1322895f-c611-4497-b1f1-89b63d940ff8	419a0dcd6f52f39db26a282fc73ee5bba4c6571821526d35905ca1303d729f80	2026-02-11 03:33:55.176492+00	20260211033354_add_auth_js_tables	\N	\N	2026-02-11 03:33:54.982893+00	1
c3fba8e2-d45d-4bee-adb5-91c5fe55bcaf	0c13531dbd801c496ef748d9457d06f3b7d188ef23d9fd52e5ec678907056255	2026-02-13 01:20:08.253301+00	20260213012008_remove_scope_type	\N	\N	2026-02-13 01:20:08.246492+00	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, user_id, type, provider, provider_account_id, refresh_token, access_token, expires_at, token_type, scope, id_token, session_state, created_at, updated_at) FROM stdin;
cmlhmd3yp0002ffak1ew6776u	cmlhmd3yi0000ffakvkg8gwm8	oidc	google	104237535269112251764	1//0gdUG9NNHaxAlCgYIARAAGBASNwF-L9Ird87DU5h1A9XIOGmvAdjupVKD2G82VyuVwfCIIbXqt66QTSGtG3h6Q6weSZ_e0N-BqPE	ya29.a0AUMWg_I4BP9uaizkyOm4PIS1N8mD2S9yNinRBemJJuVLrDN0knJf03WUxhTKG33SAiVid-yCX6QXhjqHMN4b_hLxQ3ImSks0NPRxx8tSc1K3vpT2Au8jdalpMrpDbR-4rpQFLsRL1tPjn-2v5H5bzKJWi-YxyXsqMgw6BuOy7aR1vNmv3nedBNpDFZnw3-3hKkivdM4aCgYKAccSARQSFQHGX2MiDUAz_-ir2xW8UN_EKuHHRA0206	1770793126	bearer	https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile openid	eyJhbGciOiJSUzI1NiIsImtpZCI6ImMyN2JhNDBiMDk1MjlhZDRmMTY4MjJjZTgzMTY3YzFiYzM5MTAxMjIiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI1MDEwNzkzNTE0MjUtcDZhaG80MmRkNHAyYThqcTh1bnB2c3BoOW1ic2trZ3AuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI1MDEwNzkzNTE0MjUtcDZhaG80MmRkNHAyYThqcTh1bnB2c3BoOW1ic2trZ3AuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDQyMzc1MzUyNjkxMTIyNTE3NjQiLCJlbWFpbCI6InJhY29vbndyQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhdF9oYXNoIjoiR1E5c3lEalJ2Z3FBYlBVaUUzV081QSIsIm5hbWUiOiJydW4gd3UiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jS00tM2tNaU1SVDJLdHBJY2REYUZ3WXJvYVdFbXBqUnhFMENhaTdQcXBFNXZ1cWpZRzA9czk2LWMiLCJnaXZlbl9uYW1lIjoicnVuIiwiZmFtaWx5X25hbWUiOiJ3dSIsImlhdCI6MTc3MDc4OTUyNywiZXhwIjoxNzcwNzkzMTI3fQ.Lev2419FqbaienqMjSyxoEZp0NP-IzIgYw9-qMO8zsdBUwyAg6VDQ-2JYTnQXD2wLqhjEA8_9bMZaJ_w2TdytUTvIptgIWGkKJLvhz89vT1iOnJGmNhHl9YqtAhejXZgWXT95S_r1oOUIoW8-niJnzghV63hpfLPTrGwLdu24--bR8QGrByyreCMHrJ044WvkyF1-GEWBOW3qfdKvx4MDzeyaf_SjIqcBlLe-irCHJU2x43Tq0jJV8-ZsrWD5i38gHDoys4pdkxL1rQ3nO9kxdZfz43CRd4PVLGjHvqglUG0eoC-Aa-inI5NnzP8yQLcemm8-rZ8oqJwIwMTdZSvLQ	\N	2026-02-11 05:58:47.377	2026-02-11 05:58:47.377
\.


--
-- Data for Name: apps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.apps (id, app_key, name, description, access_url, status, purchasable, allow_in_new_plan, sunset_at, archived_at, archived_reason, created_at, updated_at) FROM stdin;
1	app_1770798978245	bacc	\N	xxx	PUBLISHED	t	t	\N	\N	\N	2026-02-11 08:36:28.628	2026-02-11 08:36:36.517
\.


--
-- Data for Name: media_files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_files (id, app_id, file_name, file_type, mime_type, file_size, width, height, duration, storage_key, storage_url, thumbnail_url, tags, metadata, status, deleted_at, created_by, created_at, updated_at, user_id, generation_type, prompt_data) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, order_no, user_id, pricing_plan_id, amount, currency, status, stripe_session_id, stripe_payment_intent_id, paid_at, created_at, stripe_invoice_id, stripe_metadata, stripe_subscription_id) FROM stdin;
1	ORD-1770860899636-NJ5ILHIVD	cmlhmd3yi0000ffakvkg8gwm8	1	5.00	USD	PAID	cs_test_b1Z2PTl4yilQO2OxOyFTHa5lMSmwSRA77b7TFExTlmb6ku3HnfW9Sl2TJl	pi_3Szpqf9taR4K6AMK0czTkcM0	2026-02-12 02:44:30.729	2026-02-12 01:48:19.646	\N	{"mode": "payment", "stripePriceId": "price_1SjcpN9taR4K6AMKOgNEB5oX", "billingInterval": null}	\N
2	ORD-1770944425460-5LSSVKRHY	cmlhmd3yi0000ffakvkg8gwm8	1	5.00	USD	PAID	cs_test_b1euyMplgY2CSzCiXKtqGXEHvtrdgDMT25faX4fDCMOfhZyHVC8MkwKLfg	\N	2026-02-13 01:01:08.652	2026-02-13 01:00:25.469	\N	{"mode": "payment", "stripePriceId": "price_1SjcpN9taR4K6AMKOgNEB5oX", "billingInterval": null}	\N
\.


--
-- Data for Name: pricing_plan_apps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pricing_plan_apps (id, pricing_plan_id, app_id) FROM stdin;
1	1	1
\.


--
-- Data for Name: pricing_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pricing_plans (id, name, plan_type, price, currency, billing_interval, stripe_product_id, stripe_price_id, is_active, status, sellable, retired_at, archived_at, archived_reason, replacement_plan_id, created_at, stripe_metadata, stripe_price_id_monthly, stripe_price_id_quarterly, stripe_price_id_yearly) FROM stdin;
2	月度测试2	SUBSCRIPTION	1.00	USD	MONTH	prod_Th095S3LXLi7y8	price_1Sjc9J9taR4K6AMKuw5EVCT2	t	ACTIVE	t	\N	\N	\N	\N	2026-02-11 08:36:45.053	{}	price_1Sjc9J9taR4K6AMKuw5EVCT2	\N	\N
3	App C - 客户关系管理	ONE_TIME	5.00	USD	\N	prod_TgyRPwKsRdjiTG	price_1SjaV39taR4K6AMKDoGkTqGw	t	ACTIVE	t	\N	\N	\N	\N	2026-02-11 08:36:45.402	{}	\N	\N	\N
4	App B - 数据分析平台	ONE_TIME	5.00	USD	\N	prod_TgyRNEUXAUrSMr	price_1SjaV29taR4K6AMKZ4vL5WgY	t	ACTIVE	t	\N	\N	\N	\N	2026-02-11 08:36:45.731	{}	\N	\N	\N
5	App A - 项目管理工具	ONE_TIME	5.00	USD	\N	prod_TgyRDAxJWQ0bV0	price_1SjaV19taR4K6AMK8wzv75ro	t	ACTIVE	t	\N	\N	\N	\N	2026-02-11 08:36:46.081	{}	\N	\N	\N
6	全应用年度订阅	SUBSCRIPTION	99.00	USD	YEAR	prod_TgyR2pJzCjn8ij	price_1SjaV19taR4K6AMK2b3SUnjY	t	ACTIVE	t	\N	\N	\N	\N	2026-02-11 08:36:46.752	{}	\N	\N	price_1SjaV19taR4K6AMK2b3SUnjY
7	全应用月度订阅	SUBSCRIPTION	10.00	USD	MONTH	prod_TgyRwM04ViPBhC	price_1SjaV09taR4K6AMK02djXjzF	t	ACTIVE	t	\N	\N	\N	\N	2026-02-11 08:36:47.102	{}	price_1SjaV09taR4K6AMK02djXjzF	\N	\N
1	demo	ONE_TIME	5.00	USD	\N	prod_Th0rfZjGHv3aHd	price_1SjcpN9taR4K6AMKOgNEB5oX	t	ACTIVE	t	\N	\N	\N	\N	2026-02-11 08:36:44.711	{}	\N	\N	\N
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, session_token, user_id, expires) FROM stdin;
\.


--
-- Data for Name: user_entitlement_apps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_entitlement_apps (id, entitlement_id, app_id) FROM stdin;
1	1	1
2	2	1
\.


--
-- Data for Name: user_entitlements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_entitlements (id, user_id, source_order_id, entitlement_type, start_time, expire_time, status, stripe_subscription_id, created_at) FROM stdin;
1	cmlhmd3yi0000ffakvkg8gwm8	1	PERMANENT	2026-02-12 02:44:30.738	\N	ACTIVE	\N	2026-02-12 02:44:30.739
2	cmlhmd3yi0000ffakvkg8gwm8	2	PERMANENT	2026-02-13 01:01:08.662	\N	ACTIVE	\N	2026-02-13 01:01:08.663
\.


--
-- Data for Name: user_social_binds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_social_binds (id, user_id, provider, provider_sub, social_email, social_name, social_avatar, access_token, refresh_token, token_expires_at, raw_data, created_at, updated_at) FROM stdin;
1	cmlhmd3yi0000ffakvkg8gwm8	google	456b225b-5ade-4406-b931-7aaa58c5eb3c	racoonwr@gmail.com	run wu	https://lh3.googleusercontent.com/a/ACg8ocKM-3kMiMRT2KtpIcdDaFwYroaWEmpjRxE0Cai7PqpE5vuqjYG0=s96-c	\N	\N	\N	\N	2026-02-11 09:59:48.055	2026-02-11 09:59:48.055
2	cmlhmd3yi0000ffakvkg8gwm8	google	ae99ec7e-86b8-4a20-9129-b3e895ebfc98	racoonwr@gmail.com	run wu	https://lh3.googleusercontent.com/a/ACg8ocKM-3kMiMRT2KtpIcdDaFwYroaWEmpjRxE0Cai7PqpE5vuqjYG0=s96-c	\N	\N	\N	\N	2026-02-11 10:06:19.867	2026-02-11 10:06:19.867
3	cmlhmd3yi0000ffakvkg8gwm8	google	ddcb00ab-f30c-4599-9622-5af278bc3d4d	racoonwr@gmail.com	run wu	https://lh3.googleusercontent.com/a/ACg8ocKM-3kMiMRT2KtpIcdDaFwYroaWEmpjRxE0Cai7PqpE5vuqjYG0=s96-c	\N	\N	\N	\N	2026-02-11 10:19:09.585	2026-02-11 10:19:09.585
4	cmlhmd3yi0000ffakvkg8gwm8	google	db47991a-7a21-4dde-a79f-7ffd7054b134	racoonwr@gmail.com	run wu	https://lh3.googleusercontent.com/a/ACg8ocKM-3kMiMRT2KtpIcdDaFwYroaWEmpjRxE0Cai7PqpE5vuqjYG0=s96-c	\N	\N	\N	\N	2026-02-11 10:33:26.388	2026-02-11 10:33:26.388
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, status, stripe_customer_id, total_spend_amount, total_order_count, created_at, updated_at, email_verified, image, name) FROM stdin;
cmlhmd3yi0000ffakvkg8gwm8	racoonwr@gmail.com	\N	ACTIVE	cus_TxkV9JeqWQhqqy	10.00	2	2026-02-11 05:58:47.37	2026-02-13 01:01:08.676	\N	https://lh3.googleusercontent.com/a/ACg8ocKM-3kMiMRT2KtpIcdDaFwYroaWEmpjRxE0Cai7PqpE5vuqjYG0=s96-c	run wu
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Name: apps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.apps_id_seq', 1, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 2, true);


--
-- Name: pricing_plan_apps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pricing_plan_apps_id_seq', 1, true);


--
-- Name: pricing_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pricing_plans_id_seq', 7, true);


--
-- Name: user_entitlement_apps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_entitlement_apps_id_seq', 2, true);


--
-- Name: user_entitlements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_entitlements_id_seq', 2, true);


--
-- Name: user_social_binds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_social_binds_id_seq', 4, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: apps apps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT apps_pkey PRIMARY KEY (id);


--
-- Name: media_files media_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: pricing_plan_apps pricing_plan_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricing_plan_apps
    ADD CONSTRAINT pricing_plan_apps_pkey PRIMARY KEY (id);


--
-- Name: pricing_plans pricing_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricing_plans
    ADD CONSTRAINT pricing_plans_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: user_entitlement_apps user_entitlement_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entitlement_apps
    ADD CONSTRAINT user_entitlement_apps_pkey PRIMARY KEY (id);


--
-- Name: user_entitlements user_entitlements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entitlements
    ADD CONSTRAINT user_entitlements_pkey PRIMARY KEY (id);


--
-- Name: user_social_binds user_social_binds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_social_binds
    ADD CONSTRAINT user_social_binds_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: accounts_provider_provider_account_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX accounts_provider_provider_account_id_key ON public.accounts USING btree (provider, provider_account_id);


--
-- Name: accounts_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_user_id_idx ON public.accounts USING btree (user_id);


--
-- Name: apps_app_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX apps_app_key_key ON public.apps USING btree (app_key);


--
-- Name: media_files_app_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_files_app_id_idx ON public.media_files USING btree (app_id);


--
-- Name: media_files_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_files_created_at_idx ON public.media_files USING btree (created_at);


--
-- Name: media_files_file_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_files_file_type_idx ON public.media_files USING btree (file_type);


--
-- Name: media_files_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_files_status_idx ON public.media_files USING btree (status);


--
-- Name: media_files_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_files_user_id_created_at_idx ON public.media_files USING btree (user_id, created_at);


--
-- Name: orders_order_no_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX orders_order_no_key ON public.orders USING btree (order_no);


--
-- Name: orders_stripe_session_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_stripe_session_id_idx ON public.orders USING btree (stripe_session_id);


--
-- Name: orders_stripe_subscription_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_stripe_subscription_id_idx ON public.orders USING btree (stripe_subscription_id);


--
-- Name: pricing_plan_apps_pricing_plan_id_app_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX pricing_plan_apps_pricing_plan_id_app_id_key ON public.pricing_plan_apps USING btree (pricing_plan_id, app_id);


--
-- Name: sessions_session_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sessions_session_token_key ON public.sessions USING btree (session_token);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_id_idx ON public.sessions USING btree (user_id);


--
-- Name: user_entitlement_apps_entitlement_id_app_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_entitlement_apps_entitlement_id_app_id_key ON public.user_entitlement_apps USING btree (entitlement_id, app_id);


--
-- Name: user_entitlements_user_id_status_expire_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_entitlements_user_id_status_expire_time_idx ON public.user_entitlements USING btree (user_id, status, expire_time);


--
-- Name: user_social_binds_provider_provider_sub_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_social_binds_provider_provider_sub_key ON public.user_social_binds USING btree (provider, provider_sub);


--
-- Name: user_social_binds_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_social_binds_user_id_idx ON public.user_social_binds USING btree (user_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: verification_tokens_identifier_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX verification_tokens_identifier_token_key ON public.verification_tokens USING btree (identifier, token);


--
-- Name: verification_tokens_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX verification_tokens_token_key ON public.verification_tokens USING btree (token);


--
-- Name: accounts accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_files media_files_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_pricing_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pricing_plan_id_fkey FOREIGN KEY (pricing_plan_id) REFERENCES public.pricing_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pricing_plan_apps pricing_plan_apps_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricing_plan_apps
    ADD CONSTRAINT pricing_plan_apps_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pricing_plan_apps pricing_plan_apps_pricing_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricing_plan_apps
    ADD CONSTRAINT pricing_plan_apps_pricing_plan_id_fkey FOREIGN KEY (pricing_plan_id) REFERENCES public.pricing_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_entitlement_apps user_entitlement_apps_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entitlement_apps
    ADD CONSTRAINT user_entitlement_apps_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_entitlement_apps user_entitlement_apps_entitlement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entitlement_apps
    ADD CONSTRAINT user_entitlement_apps_entitlement_id_fkey FOREIGN KEY (entitlement_id) REFERENCES public.user_entitlements(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_entitlements user_entitlements_source_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entitlements
    ADD CONSTRAINT user_entitlements_source_order_id_fkey FOREIGN KEY (source_order_id) REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_entitlements user_entitlements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entitlements
    ADD CONSTRAINT user_entitlements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_social_binds user_social_binds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_social_binds
    ADD CONSTRAINT user_social_binds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict s8vsj1IAp6Be1PImIHJIo8V3Cf4uXhtqMqxYkrWm1iE4P1KymzUBLQl4nqtp12a

